let fetch_output_mail = [];
let fetch_output_password = [];
const login_request = () => {
    const fetch_check = document.getElementById('signin')
        let requestURL_m = 'http://localhost:3000/users';
        let request_m = new XMLHttpRequest();
        request_m.open('GET', requestURL_m);
        request_m.responseType = 'json';
        request_m.send();
        request_m.onload = function () {
            let request_result = request_m.response;
            populate(request_result);
        }

        function populate(jsonObj) {
            fetch_output_mail.push(jsonObj[0]["email"])
            fetch_output_password.push(jsonObj[0]["password"])
            console.log(fetch_output_mail);
            console.log(fetch_output_password);
        }
};

login_request();

const registration = () => {
    let mail_box = [];
    const login_mail = () => {
        document.querySelector("#signin").addEventListener("click", () => {
            const email = document.querySelector('.modal_style [type="email"]').value;
            console.log(email)
            mail_box.push(email)
            console.log(mail_box);
        });
    };
    let password_box = [];
    const Login_password = () => {
        document.querySelector("#signin").addEventListener("click", () => {
            const password = document.querySelector('.modal_style [type="password"]').value;
            console.log(password)
            password_box.push(password)
            console.log(password_box)
        });
    };


    function login_check() {
        document.querySelector('#signin').addEventListener('click', () => {
            if (mail_box[0] === fetch_output_mail[0] && password_box[0] === fetch_output_password[0]) {
                alert('correct');
                window.location = 'My_project.html';
            } else {
                alert('wrong mail!');
            }
        })
    }
    login_mail();
    Login_password();
    login_check()
};

registration();


        const db_element1 = document.getElementById('dynamic_1');
        let requestURL1 = 'http://localhost:3000/Blocks';
        let request1 = new XMLHttpRequest();
        request1.open('GET', requestURL1);
        request1.responseType = 'json';
        request1.send();
        request1.onload = function () {
            let request_result = request1.response;
            populate_db1(request_result);
        }

        function populate_db1(jsonObj) {
            let pdb = document.createElement('p');
            pdb.textContent = jsonObj[0]['text'];
            db_element1.appendChild(pdb);
        }

        const db_element2 = document.getElementById('dynamic_2');
        let requestURL2 = 'http://localhost:3000/Blocks';
        let request2 = new XMLHttpRequest();
        request2.open('GET', requestURL2);
        request2.responseType = 'json';
        request2.send();
        request2.onload = function () {
            let request_result = request2.response;
            populate_db2(request_result);
        }

        function populate_db2(jsonObj) {
            let pdb = document.createElement('p');
            pdb.textContent = jsonObj[1]['text'];
            db_element2.appendChild(pdb);
        }

        const db_element3 = document.getElementById('dynamic_3');
        let requestURL3 = 'http://localhost:3000/Blocks';
        let request3 = new XMLHttpRequest();
        request3.open('GET', requestURL3);
        request3.responseType = 'json';
        request3.send();
        request3.onload = function () {
            let request_result = request3.response;
            populate_db3(request_result);
        }

        function populate_db3(jsonObj) {
            let pdb = document.createElement('p');
            pdb.textContent = jsonObj[2]['text'];
            db_element3.appendChild(pdb);
        }

let active_user = 20;
let user_no_active = 0;
let countdown = setInterval(() => {
    user_no_active++;
}, 1000)
document.body.addEventListener("mouseover", () => {
    user_no_active = 1;
})
let Logout = setInterval(() => {
    if (active_user === user_no_active) {
        alert("your session is out.")
        window.location = "My_project.html"
    }
}, 1000)


